from setuptools import setup

setup(name='jsonplaceapi',
version='0.0.1',
description='Jsonplaceholder REST api',
url='https://github.com/defloppka/jsonplaceapi',
author='defloppka',
author_email='defloppka@gmail.com',
license='MIT',
packages=['jsonplaceapi'],
zip_safe=False)