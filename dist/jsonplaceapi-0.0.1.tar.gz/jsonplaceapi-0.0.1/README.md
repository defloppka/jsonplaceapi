# Jsonplaceapi

## Simple library to interact with [Jsonplaceholder](https://jsonplaceholder.typicode.com)


![Example](./code.png)